import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Sample dataset
sample_data = {
    'ticket': [
        'I cannot log into my account',
        'Payment failed during checkout',
        'How do I reset my password?',
        'App crashes when I open it',
        'Need help with subscription cancellation',
        'Received wrong item in my order',
        'Website is not loading',
        'Unable to update profile information',
        'Refund not processed yet',
        'Error message when uploading documents'
    ],
    'category': [
        'Login Issue',
        'Payment Issue',
        'Login Issue',
        'App Crash',
        'Subscription',
        'Order Issue',
        'Website Issue',
        'Profile Issue',
        'Refund Issue',
        'Upload Issue'
    ]
}

df = pd.DataFrame(sample_data)

@st.cache_data
def train_model(data):
    X = data['ticket']
    y = data['category']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    vectorizer = TfidfVectorizer()
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    clf = LogisticRegression()
    clf.fit(X_train_vec, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test_vec))
    return clf, vectorizer, acc

model, vectorizer, accuracy = train_model(df)

st.title("🛠️ Customer Support Ticket Classifier")
st.write("Classify support tickets into categories using machine learning.")

st.metric(label="Model Accuracy", value=f"{accuracy*100:.2f}%")

ticket_input = st.text_area("Enter your support ticket:")

if st.button("Classify"):
    if ticket_input.strip():
        input_vec = vectorizer.transform([ticket_input])
        prediction = model.predict(input_vec)[0]
        st.success(f"Predicted Category: **{prediction}**")
    else:
        st.warning("Please enter a ticket description.")

with st.expander("📊 View Sample Training Data"):
    st.dataframe(df)
